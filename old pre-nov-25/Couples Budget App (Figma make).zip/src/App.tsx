import { useState } from 'react';
import { Navigation } from './components/Navigation';
import { Dashboard } from './components/Dashboard';
import { ExpenseForm } from './components/ExpenseForm';
import { ExpenseList } from './components/ExpenseList';
import { BudgetManager } from './components/BudgetManager';
import { Analytics } from './components/Analytics';
import { BillSplitting } from './components/BillSplitting';
import { MonthlyStatement } from './components/MonthlyStatement';
import { mockUsers, mockExpenses, mockBudgets, mockIncome } from './lib/mockData';
import { Expense, Budget } from './types';
import { Toaster } from './components/ui/sonner';
import { toast } from 'sonner@2.0.3';

export default function App() {
  const [currentView, setCurrentView] = useState('dashboard');
  const [expenses, setExpenses] = useState<Expense[]>(mockExpenses);
  const [budgets, setBudgets] = useState<Budget[]>(mockBudgets);
  const [currentUser] = useState(mockUsers[0]);
  const [partnerUser] = useState(mockUsers[1]);
  const [income] = useState(mockIncome);

  const handleAddExpense = (newExpense: Omit<Expense, 'id'>) => {
    const expense: Expense = {
      ...newExpense,
      id: Date.now().toString()
    };
    setExpenses([...expenses, expense]);
    toast.success('Expense added successfully!');
    setCurrentView('dashboard');
  };

  const handleDeleteExpense = (id: string) => {
    setExpenses(expenses.filter(exp => exp.id !== id));
    toast.success('Expense deleted');
  };

  const handleUpdateBudget = (budget: Budget) => {
    const existingIndex = budgets.findIndex(b => b.id === budget.id);
    if (existingIndex >= 0) {
      const updated = [...budgets];
      updated[existingIndex] = budget;
      setBudgets(updated);
      toast.success('Budget updated');
    } else {
      setBudgets([...budgets, budget]);
      toast.success('Budget created');
    }
  };

  const handleDeleteBudget = (id: string) => {
    setBudgets(budgets.filter(b => b.id !== id));
    toast.success('Budget deleted');
  };

  const renderView = () => {
    switch (currentView) {
      case 'dashboard':
        return (
          <Dashboard
            expenses={expenses}
            budgets={budgets}
            currentUser={currentUser}
            onNavigate={setCurrentView}
          />
        );
      case 'add-expense':
        return (
          <ExpenseForm
            currentUser={currentUser}
            partnerUser={partnerUser}
            onAddExpense={handleAddExpense}
            onCancel={() => setCurrentView('dashboard')}
          />
        );
      case 'expenses':
        return (
          <ExpenseList
            expenses={expenses}
            currentUser={currentUser}
            partnerUser={partnerUser}
            onDeleteExpense={handleDeleteExpense}
            onNavigate={setCurrentView}
          />
        );
      case 'budgets':
        return (
          <BudgetManager
            budgets={budgets}
            expenses={expenses}
            onUpdateBudget={handleUpdateBudget}
            onDeleteBudget={handleDeleteBudget}
            onNavigate={setCurrentView}
          />
        );
      case 'analytics':
        return (
          <Analytics
            expenses={expenses}
            budgets={budgets}
            onNavigate={setCurrentView}
          />
        );
      case 'split':
        return (
          <BillSplitting
            expenses={expenses}
            currentUser={currentUser}
            partnerUser={partnerUser}
            onNavigate={setCurrentView}
          />
        );
      case 'statement':
        return (
          <MonthlyStatement
            expenses={expenses}
            budgets={budgets}
            income={income}
            currentUser={currentUser}
            partnerUser={partnerUser}
            onNavigate={setCurrentView}
          />
        );
      default:
        return (
          <Dashboard
            expenses={expenses}
            budgets={budgets}
            currentUser={currentUser}
            onNavigate={setCurrentView}
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navigation currentView={currentView} onNavigate={setCurrentView} />
      <main className="mx-auto max-w-7xl">
        {renderView()}
      </main>
      <Toaster />
    </div>
  );
}
