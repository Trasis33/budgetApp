import { Button } from './ui/button';
import { LayoutDashboard, Receipt, PieChart, DollarSign, BarChart3, FileText, Users } from 'lucide-react';

interface NavigationProps {
  currentView: string;
  onNavigate: (view: string) => void;
}

export function Navigation({ currentView, onNavigate }: NavigationProps) {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'add-expense', label: 'Add Expense', icon: Receipt },
    { id: 'expenses', label: 'Expenses', icon: DollarSign },
    { id: 'budgets', label: 'Budgets', icon: BarChart3 },
    { id: 'analytics', label: 'Analytics', icon: PieChart },
    { id: 'split', label: 'Bill Splitting', icon: Users },
    { id: 'statement', label: 'Statements', icon: FileText }
  ];

  return (
    <nav className="border-b bg-background">
      <div className="flex items-center h-16 px-6">
        <div className="flex items-center gap-2 mr-8">
          <DollarSign className="h-6 w-6 text-primary" />
          <span>CouplesFlow</span>
        </div>
        
        <div className="hidden md:flex items-center gap-1">
          {navItems.map(item => {
            const Icon = item.icon;
            return (
              <Button
                key={item.id}
                variant={currentView === item.id ? 'default' : 'ghost'}
                onClick={() => onNavigate(item.id)}
                className="gap-2"
              >
                <Icon className="h-4 w-4" />
                {item.label}
              </Button>
            );
          })}
        </div>

        <div className="md:hidden flex gap-1 overflow-x-auto">
          {navItems.map(item => {
            const Icon = item.icon;
            return (
              <Button
                key={item.id}
                variant={currentView === item.id ? 'default' : 'ghost'}
                size="sm"
                onClick={() => onNavigate(item.id)}
              >
                <Icon className="h-4 w-4" />
              </Button>
            );
          })}
        </div>
      </div>
    </nav>
  );
}
