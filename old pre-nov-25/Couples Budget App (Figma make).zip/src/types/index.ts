export interface User {
  id: string;
  name: string;
  email: string;
}

export interface Expense {
  id: string;
  date: string;
  amount: number;
  category: string;
  description: string;
  paidBy: string;
  splitType: 'equal' | 'custom' | 'personal';
  splitRatio?: number; // percentage for custom splits
  recurring?: boolean;
  recurringDay?: number;
}

export interface Budget {
  id: string;
  category: string;
  monthlyAmount: number;
  spent?: number;
}

export interface Income {
  id: string;
  source: string;
  amount: number;
  date: string;
}

export const CATEGORIES = [
  'Housing',
  'Food',
  'Transportation',
  'Entertainment',
  'Utilities',
  'Shopping',
  'Healthcare',
  'Savings',
  'Other'
] as const;

export type Category = typeof CATEGORIES[number];
