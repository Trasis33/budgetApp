
  # Couples Budget App

  This is a code bundle for Couples Budget App. The original project is available at https://www.figma.com/design/C98CFDhbgQgJm8jcQLA3Ua/Couples-Budget-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  